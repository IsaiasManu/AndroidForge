# VozPuente Android — prototipo inicial

Este proyecto es un punto de partida para Android. Incluye:
- pantalla inicial de VozPuente
- solicitud del permiso para mostrar sobre otras aplicaciones
- ventana flotante movible
- mensajes de ejemplo, pausa/reanudación y cierre
- flujo de GitHub Actions para compilar un APK de prueba en la nube

## Importante
Esta versión **no** captura audio de Talkin, no reconoce voces, no separa hablantes, no traduce audio real y no envía respuestas. Los textos que aparecen son demostrativos. Es solo el primer paso para probar la ventana flotante.

## Compilar desde el celular con GitHub Actions
1. Creá un repositorio nuevo en GitHub.
2. Subí el contenido de esta carpeta al repositorio (no solo el archivo ZIP).
3. En la pestaña **Actions**, habilitá los workflows si GitHub lo solicita.
4. Abrí **Build VozPuente APK** y tocá **Run workflow**. También se ejecuta al subir cambios a `main` o `master`.
5. Cuando termine, entrá en la ejecución y descargá el artefacto **VozPuente-debug-apk**.
6. Descomprimí el artefacto y abrí `app-debug.apk` en tu Samsung. Android puede pedir permiso para instalar apps desde el navegador/archivos.
7. Abrí VozPuente, tocá **Activar ventana flotante**, concedé el permiso de superposición y volvé a tocar el botón.

El APK de depuración sirve para pruebas, no es una publicación final de Play Store.

## Alternativa de compilación web
Se puede investigar un servicio externo de compilación desde el navegador, pero revisá cuidadosamente sus permisos. Nunca compartas tu contraseña ni un token personal de GitHub en el chat. Un token puede dar acceso a tu cuenta; crealo solo si entendés los permisos solicitados y revocalo cuando termines.

## Próximas etapas
1. Comprobar si Talkin permite capturar su audio en ese dispositivo.
2. Capturar audio solo con los permisos y consentimientos necesarios.
3. Transcribir y separar voces en Persona A/B/C.
4. Traducir cada intervención al español.
5. Preparar respuestas traducidas para que las apruebes manualmente.
