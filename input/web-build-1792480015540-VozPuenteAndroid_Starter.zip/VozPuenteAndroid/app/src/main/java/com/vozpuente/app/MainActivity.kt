package com.vozpuente.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(23, 23, 23))
        }
        val title = TextView(this).apply {
            text = "VozPuente"
            textSize = 30f
            setTextColor(Color.WHITE)
        }
        val subtitle = TextView(this).apply {
            text = "Traductor flotante para salas de voz"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 24)
        }
        val info = TextView(this).apply {
            text = "Esta primera versión prueba la ventana flotante. Todavía no captura ni traduce audio real."
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 24)
        }
        val start = Button(this).apply {
            text = "Activar ventana flotante"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    finish()
                } else {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                }
            }
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(info)
        root.addView(start, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        // After the permission screen, the user can tap the button again to start the overlay.
    }
}
