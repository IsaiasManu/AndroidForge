package com.vozpuente.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var overlay: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private var paused = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    private fun showOverlay() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(Color.rgb(28, 28, 28))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "◉ VozPuente"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 18, 0)
        }
        val pauseButton = TextView(this).apply {
            text = "Ⅱ"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(10, 0, 10, 0)
            setOnClickListener {
                paused = !paused
                text = if (paused) "▶" else "Ⅱ"
                transcript.text = if (paused) "Traducción pausada" else sampleText()
            }
        }
        val closeButton = TextView(this).apply {
            text = "×"
            textSize = 24f
            setTextColor(Color.LTGRAY)
            setPadding(10, 0, 0, 0)
            setOnClickListener { stopSelf() }
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(pauseButton)
        header.addView(closeButton)
        panel.addView(header)

        val line = View(this).apply {
            setBackgroundColor(Color.DKGRAY)
        }
        panel.addView(line, LinearLayout.LayoutParams(-1, 1).apply {
            topMargin = 8
            bottomMargin = 10
        })

        val transcript = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            setLineSpacing(3f, 1f)
            text = sampleText()
        }
        // Keep reference for the pause/resume button.
        this.transcript = transcript
        panel.addView(transcript)

        val hint = TextView(this).apply {
            text = "Arrastrá desde aquí para mover"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            setPadding(0, 10, 0, 0)
        }
        panel.addView(hint)

        params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.78f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 18
            y = 140
        }

        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        hint.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchX).toInt()
                    params.y = initialY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(panel, params)
                    true
                }
                else -> false
            }
        }

        overlay = panel
        windowManager.addView(panel, params)
    }

    private lateinit var transcript: TextView

    private fun sampleText() =
        "PERSONA A · INGLÉS\nWhere are you from?\n¿De dónde sos?\n\n" +
        "PERSONA B · PORTUGUÉS\nVocê fala espanhol?\n¿Hablás español?"

    override fun onDestroy() {
        overlay?.let {
            if (it.isAttachedToWindow) windowManager.removeView(it)
        }
        overlay = null
        super.onDestroy()
    }
}
